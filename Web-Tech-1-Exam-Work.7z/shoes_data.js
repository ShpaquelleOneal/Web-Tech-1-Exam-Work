var shoes = [
    {
        "Name": "Archegos-1",
        "Color": "Black",
        "Gender": "Male",
        "Release date": "2022-12-25",
        "Cart": 0,
        "Description": "Step outside your comfort zone and into bold style with the Nike Air Max Plus, a Tuned Air experience that offers premium stability and unbelievable cushioning as you explore new horizons. Featuring airy mesh, bold gradient colours and the wavy design lines of the original, they celebrate defiant style."
    },
    {
        "Name": "CityLook-22",
        "Color": "Black / White",
        "Gender": "Male",
        "Release date": "2023-01-25",
        "Cart": 0,
        "Description": "Meet the street-level favourite you'll want to wear on repeat—just like the Swoosh designs running down the pull tab on the heels. With its stretchy bootie-like upper, crisp leather accents, Nike Air cushioning and futuristic heel cage, the Huarache is bragging rights for your feet."
    },
    {
        "Name": "Rocky_Citadel",
        "Color": "Beige",
        "Gender": "Female",
        "Release date": "2022-12-27",
        "Cart": 0,
        "Description": "We design the Elite boot for you and the world's biggest stars to give you high-level quality because you demand greatness from yourself and your footwear."
    },
    {
        "Name": "Panther-white-02",
        "Color": "Pink",
        "Gender": "Female",
        "Release date": "2022-11-01",
        "Cart": 0,
        "Description": "Paying homage to both heritage and innovation, we've blended two icons to go beyond what's expected."
    },
]